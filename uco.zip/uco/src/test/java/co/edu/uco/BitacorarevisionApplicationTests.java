package co.edu.uco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BitacorarevisionApplicationTests {

	@Test
	void contextLoads() {
	}

}
